pip install weasyprint

https://weasyprint.readthedocs.io/en/latest/install.html#windows

https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer/releases


aplicar na variável de ambiente  C:\Program Files\GTK3-Runtime Win64\bin


 pip install pdfkit

 https://wkhtmltopdf.org/downloads.html




  pip install flask flask_sqlalchemy flask_login werkzeug   
   pip install flask flask_sqlalchemy flask_login          

    .\venv\Scripts\activate    
    from your_app_file inport db    
    pip install flask flask-login werkzeug       
     set PYTHONPATH=C:\ForPoint\V3\ordem_servico_app    
     pip install -r requirements.txt 
      pip install flask flask-login  
      pip install reportlab                                                      
     python -m venv venv     
      python -m venv venv     